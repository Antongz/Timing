DROP DATABASE IF EXISTS `timing`;
CREATE DATABASE `timing`;
USE timing;

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL,
  `admin` TINYINT DEFAULT 0,
  `first_name` varchar(20) DEFAULT NULL,
  `family_name` varchar(20) DEFAULT NULL,
  `full_name` varchar(20) DEFAULT NULL,
  `email` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `user_password` varchar(15) CHARACTER SET utf8 DEFAULT NULL,
  `status_id` TINYINT DEFAULT 0,
  PRIMARY KEY (`user_id`)
);

DROP TABLE IF EXISTS `user_profile`;

CREATE TABLE `user_profile` (
  `user_id` int(11) NOT NULL,
  `icon` varchar(50) DEFAULT NULL,
  FOREIGN KEY (user_id) REFERENCES user(user_id)
);

DROP TABLE IF EXISTS `task`;

CREATE TABLE `task` (
  `task_id` int(11) NOT NULL,
  `task_title` varchar(50) DEFAULT NULL,
  `task_date` varchar(60) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `priority` varchar(20) DEFAULT NULL,
  `task_assign` varchar(60) DEFAULT NULL,
  `task_assignby` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`task_id`)
);

DROP TABLE IF EXISTS `task_status`;

CREATE TABLE `task_status` (
  `task_id` int(11) NOT NULL,
  `status` TINYINT DEFAULT 0,
  FOREIGN KEY (task_id) REFERENCES task(task_id)
);

DROP TABLE IF EXISTS `category`;

CREATE TABLE `category` (
  `category_id` int(11) NOT NULL,
  `category` varchar(20) DEFAULT NULL,
  `category_style` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
);

INSERT INTO task VALUES (1,'Redesign the contact form screen ending','2020-06-02T08:00:20',1,'Webpage Design','Long-Term','Antongz Luc,Dan Druff','Antongz Luc');
INSERT INTO task VALUES (2,'IOS App update','2020-06-04T06:33:19',3,'IOS App','Daily','Antongz Luc,Ken Chen','Admin Marker');
INSERT INTO task VALUES (3,'Database update','2020-06-05T07:30:00',3,'Database','Daily','Antongz Luc','Admin Marker');
INSERT INTO task VALUES (4,'Database fix','2020-06-05T09:30:00',5,'Database','Urgent','Antongz Luc','Hanna Ye');
INSERT INTO task VALUES (5,'Redesign the webpage animation','2020-06-08T12:30:33',5,'Webpage Design','Long-Term','Antongz Luc,Ken Chen,Anna Sthesia,Hanna Ye','Hanna Ye');
INSERT INTO task VALUES (6,'Fix bug','2020-06-10T12:30:33',8,'Internet Security','Urgent','Antongz Luc,Nai Luc,Hanna Ye','Ken Chen');
INSERT INTO task VALUES (7,'XSS bug','2020-06-19T08:14:23',1,'Internet Security','Urgent','Antongz Luc,Nai Luc,Hanna Ye,Ken Chen','Antongz Luc');
INSERT INTO task VALUES (8,'Landing page for secret project','2020-06-24T14:30:33',7,'Webpage Design','Long-Term','Antongz Luc,Nai Luc,Hanna Ye,Ken Chen','Dan Druff');
INSERT INTO task VALUES (9,'Fix critical crashes','2020-06-24T15:20:33',7,'IOS App','Urgent','Antongz Luc,Nai Luc,Dan Druff,Ken Chen','Dan Druff');

INSERT INTO user VALUES (1,1,'Antongz','Luc','Antongz Luc','sallyushaz@gmail.com','1997520asd123',0);
INSERT INTO user VALUES (2,0,'Nai','Luc','Nai Luc','eatingluc@gmail.com','18650219970...',0);
INSERT INTO user VALUES (3,1,'Admin','Marker','Admin Marker','admin@gmail.com','admin',0);
INSERT INTO user VALUES (4,0,'Anna','Sthesia','Anna Sthesia','anna5487@gmail.com','anna5487',0);
INSERT INTO user VALUES (5,1,'Hanna','Ye','Hanna Ye','hannaya@gmail.com','hannaya',0);
INSERT INTO user VALUES (6,0,'Brock','Lee','Brock Lee','brockrock@gmail.com','rockrocklee',0);
INSERT INTO user VALUES (7,1,'Dan','Druff','Dan Druff','dammmm@gmail.com','dandruffmmmm',0);
INSERT INTO user VALUES (8,1,'Ken','Chen','Ken Chen','ken@gmail.com','kena11111',0);

INSERT INTO user_profile VALUES (1,'images/page-img/g5.jpg');
INSERT INTO user_profile VALUES (2,'images/user/02.jpg');
INSERT INTO user_profile VALUES (3,'images/user/08.jpg');
INSERT INTO user_profile VALUES (4,'images/user/01.jpg');
INSERT INTO user_profile VALUES (5,'images/user/04.jpg');
INSERT INTO user_profile VALUES (6,'images/user/05.jpg');
INSERT INTO user_profile VALUES (7,'images/user/09.jpg');
INSERT INTO user_profile VALUES (8,'images/user/10.jpg');

INSERT INTO category VALUES (1,'Webpage Design','text-warning');
INSERT INTO category VALUES (2,'Database','text-danger');
INSERT INTO category VALUES (3,'Internet Security','text-primary');
INSERT INTO category VALUES (4,'IOS App','text-info');
