function getuser() {
    $.ajax({
        url: '/getuser',
        type: 'post',
        dataType: 'JSON',
        success: function(response) {
            var len = response.length;
            for (var i = 0; i < len; i++) {
                var user_id = response[i].user_id;
                var full_name = response[i].full_name;
                var email = response[i].email;
                var icon = response[i].icon;
                var user_status = response[i].status_id;
                var status;
                var color;

                if (user_status) {
                    status = "Active";
                    color = "iq-bg-success";
                }
                else {
                    status = "Inactive";
                    color = "iq-bg-danger";
                }

                //console.log(status);

                var render = '<tr>\
                                <td class="text-center"><img class="rounded-circle img-fluid avatar-40" src="' + icon + '" alt="profile"></td>\
                                     <td>' + full_name + '</td>\
                                     <td>' + email + '</td>\
                                     <td><span class="badge ' + color + '">' + status + '</span></td>\
                                 <td>\
                                 <div class="flex align-items-center list-user-action">\
                                      <a data-toggle="tooltip" data-placement="top" title="" data-original-title="Add" href="#"><i class="ri-user-add-line"></i></a>\
                                      <a data-toggle="tooltip" data-placement="top" title="" data-original-title="Edit" href="#"><i class="ri-pencil-line"></i></a>\
                                      <a data-toggle="tooltip" data-placement="top" title="" data-original-title="Delete" href="#"><i class="ri-delete-bin-line"></i></a>\
                                    </div>\
                                     </td>\
                              </tr>';
                $("#userlistpage").append(render);
            }

        }
    });
}

$(document).ready(getuser);
