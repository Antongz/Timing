/*----------------------------------------------
Render page
------------------------------------------------*/


/*----------------------------------------------
Top Nav Bar
------------------------------------------------*/
$("#navbar").ready(
    function() {
        var xhttp = new XMLHttpRequest();

        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById("navbar").innerHTML = this.responseText;
            }
        };
        xhttp.open("GET", "/render_nav_bar", true);
        xhttp.send();
    });


/*----------------------------------------------
Top Side Bar
------------------------------------------------*/

$("#render_sidebar").ready(
    function() {
        var xhttp = new XMLHttpRequest();

        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById("render_sidebar").innerHTML = this.responseText;
            }
        };
        xhttp.open("GET", "/sidebar", true);
        xhttp.send();
    });
