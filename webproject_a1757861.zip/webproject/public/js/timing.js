/* AJAX Login */
function login() {

    console.log("Login");

    var xhttp = new XMLHttpRequest();

    xhttp.onreadystatechange = function() {
        if (this.readyState == 2 && this.status == 200) {

            // Login Successful, redirect to URL paramter "todo"
            $('#status').text("Login Successful...");

            window.location.href = 'todo';

        }
        else if (this.readyState == 2 && this.status >= 400) {

            // Login Failed
            $('#status').text("Login Failed.");
            window.location.href = 'sign-up';

        }
    };

    var credentials = {
        email: $('#email').val(),
        password: $('#password').val()
    };
    xhttp.open("POST", "/login", true);
    xhttp.setRequestHeader("Content-type", "application/json");
    xhttp.send(JSON.stringify(credentials));

}

/* AJAX Logout */
function signout() {

    console.log("Logout");

    var xhttp = new XMLHttpRequest();

    xhttp.onreadystatechange = function() {
        if (this.readyState == 2 && this.status == 200) {

            // Logout Successful, redirect to home
            window.location.pathname = "/";

        }
    };

    xhttp.open("POST", "/signout", true);
    xhttp.send();
}


/* Pull GET params from URL */
function findGetParameter(parameterName) {
    var result = "";
    var tmp = [];
    location.search
        .substr(1)
        .split("&")
        .forEach(function(item) {
            tmp = item.split("=");
            if (tmp[0] === parameterName) result = decodeURIComponent(tmp[1]);
        });
    return result;
}

function func() {
    return false;
}

/* AJAX signup */
var admincheck = 0;

function admin() {
    if ($("#customCheck2").is(":checked")) {
        admincheck = $("#customCheck2").val();
    }
    else {
        admincheck = 0;
    }
    console.log(admincheck);
}

function signup() {

    console.log("signup");

    var xhttp = new XMLHttpRequest();

    xhttp.onreadystatechange = function() {
        if (this.readyState == 2 && this.status == 200) {

            console.log("sign up successful");

            window.location.href = 'sign-in';

        }
        else if (this.readyState == 2 && this.status >= 400) {

            console.log("signup failed");
            window.location.href = 'sign-up';

        }
    };
    admin();
    var credentials = {
        first_name: $('#firstname').val(),
        family_name: $('#familyname').val(),
        email: $('#email').val(),
        password: $('#password').val(),
        admin: admincheck
    };

    xhttp.open("POST", "/signup", true);
    xhttp.setRequestHeader("Content-type", "application/json");
    xhttp.send(JSON.stringify(credentials));
}

/*----------------------------------------------
Render Footer
------------------------------------------------*/
$("#footer").ready(
    function() {
        var xhttp = new XMLHttpRequest();

        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById("footer").innerHTML = this.responseText;
            }
        };
        xhttp.open("GET", "/footer", true);
        xhttp.send();
    });
