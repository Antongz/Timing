function book_appointment() {

    console.log("book appointment");

    var xhttp = new XMLHttpRequest();

    xhttp.onreadystatechange = function() {
        if (this.readyState == 2 && this.status == 200) {

            console.log("book appointment successful");

        }
        else if (this.readyState == 2 && this.status >= 400) {

            // add Failed
            console.log("book appointment failed");

        }
    };

    //var credentials = {
    //username: $('#username').val(),
    //email: $('#email').val(),
    //password: $('#password').val()
    //};

    var credentials = {
        sendmessage: 'send successful'
    };

    xhttp.open("POST", "/book_appointment", true);
    xhttp.setRequestHeader("Content-type", "application/json");
    xhttp.send(JSON.stringify(credentials));
}

function add_classification() {

    console.log("add classification");

    var xhttp = new XMLHttpRequest();

    xhttp.onreadystatechange = function() {
        if (this.readyState == 2 && this.status == 200) {

            console.log("add classification successful");

        }
        else if (this.readyState == 2 && this.status >= 400) {

            // add Failed
            console.log("add classification failed");

        }
    };


    var credentials = {
        sendmessage: 'send successful'
    };

    xhttp.open("POST", "/add_classification", true);
    xhttp.setRequestHeader("Content-type", "application/json");
    xhttp.send(JSON.stringify(credentials));
}

// calender 1 js
if (jQuery('#calendar1').length) {
    document.addEventListener('DOMContentLoaded', function() {
        var calendarEl = document.getElementById('calendar1');

        var calendar1 = new FullCalendar.Calendar(calendarEl, {
            plugins: ['timeGrid', 'dayGrid', 'list'],
            timeZone: 'UTC',
            defaultView: 'dayGridMonth',
            header: {
                left: 'prev,next today',
                center: 'title',
                right: 'dayGridMonth,timeGridWeek,timeGridDay,listWeek'
            },
            events: [{
                title: 'Welcome to Timing',
                start: '2019-12-01',
                color: '#fc9919'
            }]
        });

        $.ajax({
            type: "post",
            url: '/getevent',
            dataType: 'JSON',
            async: false,
            success: function(response) {
                var len = response.length;
                for (var i = 0; i < len; i++) {
                    var style = response[i].category_style;
                    var color;

                    if (style == 'text-warning') {
                        color = '#fbdb3c';
                    }
                    else if (style == 'text-danger') {
                        color = '#f36a83';
                    }
                    else if (style == 'text-primary') {
                        color = '#4F6272';
                    }
                    else {
                        color = "#3fa9ff";
                    }

                    calendar1.addEvent({
                        title: '' + response[i].task_title + '',
                        start: '' + response[i].task_date + '',
                        color: '' + color + ''
                    });
                    //console.log(json);
                }
            }
        });
        calendar1.render();
    });
}

function get_schedule() {
    $.ajax({
        url: '/getschedule',
        type: 'post',
        dataType: 'JSON',
        success: function(response) {
            var len = response.length;
            for (var i = 0; i < len; i++) {
                var title = response[i].task_title;
                var category_style = response[i].category_style;

                var render = '<li class="d-flex">\
                                        <div class="schedule-icon"><i class="ri-checkbox-blank-circle-fill ' + category_style + '"></i></div>\
                                        <div class="schedule-text"> <span>' + title + '</span>\
                                            <span> </span></div>\
                                    </li>';
                $("#schedule").append(render);
            }

        }
    });
}

$(document).ready(get_schedule);
