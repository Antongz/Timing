//Inset date on todo page#
var getdate = '';

function th() {
    var myDate = new Date();
    var day = to2(myDate.getDate());
    if (day == '01') {
        return 'st';
    }
    else if (day == '02') {
        return 'nd';
    }
    else if (day == '03') {
        return 'rd';
    }
    else {
        return 'th';
    }
}

function formatDate() {
    var myDate = new Date();
    var year = myDate.getFullYear();
    var month = to2(myDate.getMonth() + 1);
    var day = to2(myDate.getDate());
    var hour = to2(myDate.getHours());
    var minute = to2(myDate.getMinutes());
    var second = to2(myDate.getSeconds());


    getdate = day + th() + ' ' + month + ', ' + year;
    return year + "-" + month + "-" + day;
    //Date with time
    // return year + "-" + month + "-" + day + " " + hour + ":" + minute + ":" + second;
    // document.write(year+"-"+month+"-"+day+" "+hour+":"+minute+":"+second);
}

function senddate() {
    var myDate = new Date();
    var year = myDate.getFullYear();
    var month = to2(myDate.getMonth() + 1);
    var day = to2(myDate.getDate());
    var hour = to2(myDate.getHours());
    var minute = to2(myDate.getMinutes());
    var second = to2(myDate.getSeconds());


    return year + "-" + month + "-" + day + "T" + hour + ":" + minute + ":" + second;
    // document.write(year+"-"+month+"-"+day+" "+hour+":"+minute+":"+second);
}

function to2(m) {
    if (m < 10) {
        return '0' + m;
    }
    return m;
}

function getMyDay(date) {
    var week;
    if (date.getDay() == 0) week = "Sunday";
    if (date.getDay() == 1) week = "Monday";
    if (date.getDay() == 2) week = "Tuesday";
    if (date.getDay() == 3) week = "Wednesday";
    if (date.getDay() == 4) week = "Thursday";
    if (date.getDay() == 5) week = "Friday";
    if (date.getDay() == 6) week = "Saturday";
    return week;
}

var getday = getMyDay(new Date(formatDate()));

var datenow = document.getElementById("datenow");
datenow.innerText = getday + ', ' + getdate;

var checked;
$('[name=priority]').change(function() {
    checked = $('[name=priority]:checked');
    console.log('Choose:', checked.val());
});

var u_select;
var c_select;

function addtask() {

    console.log("addtask");

    var xhttp = new XMLHttpRequest();

    xhttp.onreadystatechange = function() {
        if (this.readyState == 2 && this.status == 200) {

            console.log("addtask successful");

        }
        else if (this.readyState == 2 && this.status >= 400) {

            // add Failed
            console.log("addtask failed");

        }
    };

    var getdate = senddate();
    var credentials = {
        task_title: $('#task_tile').val(),
        u_select: u_select,
        c_select: c_select,
        priority: checked.val(),
        date: getdate
    };

    xhttp.open("POST", "/addtask", true);
    xhttp.setRequestHeader("Content-type", "application/json");
    xhttp.send(JSON.stringify(credentials));
}

function sumittask() {
    // && u_select && c_select && checked.val()
    var gettitle = $('#task_tile').val();

    if (gettitle && u_select && c_select && checked.val()) {
        addtask();
        $("#tasklist").empty();
        gettask();
    }
    else {
        return 0;
    }
}

function category_task() {
    $("#tasklist").empty();
    gettask();
}

function addcategory() {

    console.log("addcategory");

    var xhttp = new XMLHttpRequest();

    xhttp.onreadystatechange = function() {
        if (this.readyState == 2 && this.status == 200) {

            console.log("addcategory successful");

        }
        else if (this.readyState == 2 && this.status >= 400) {

            // add Failed
            console.log("addcategory failed");

        }
    };

    //var credentials = {
    //username: $('#username').val(),
    //email: $('#email').val(),
    //password: $('#password').val()
    //};

    var credentials = {
        sendmessage: 'send successful'
    };

    xhttp.open("POST", "/addcategory", true);
    xhttp.setRequestHeader("Content-type", "application/json");
    xhttp.send(JSON.stringify(credentials));
}

Vue.component('v-select', VueSelect.VueSelect);

var select_user = new Vue({
    el: '#users',
    data: function() {
        return {
            selected: [],
            options: [],
            users: [],
            placeholder: 'Choose Users to assign..'
        };
    },
    mounted: function() {
        var user_filter = function(obj) {
            return this.users.indexOf(obj.user_id) > -1;
        };
        this.selected = this.options.filter(user_filter, this);
    },
    methods: {
        selected_user: function(values) {
            this.users = values.map(function(obj) {
                return obj.full_name;
            });
            u_select = this.users;
            //console.log(u_select);
        },
    }
});

//push user to vue
function vue_user() {
    $.ajax({
        type: "post",
        url: '/getuser',
        async: false,
        success: function(response) {
            var len = response.length;
            for (var i = 0; i < len; i++) {
                var json = { "user_id": response[i].user_id, "full_name": response[i].full_name };
                select_user.options.push(json);

                var user_id = response[i].user_id;
                var full_name = response[i].full_name;
                var email = response[i].email;
                var icon = response[i].icon;

                var render = ' <li class="d-flex mb-4 align-items-center">\
                                                        <div class="user-img img-fluid"><img src="' + icon + '" alt="story-img" class="rounded-circle avatar-40"></div>\
                                                        <div class="media-support-info ml-3">\
                                                            <h6>' + full_name + '</h6>\
                                                            <p class="mb-0">' + email + '</p>\
                                                        </div>\
                                                        <div class="iq-card-header-toolbar d-flex align-items-center">\
                                                            <div class="dropdown">\
                                                                <span class="dropdown-toggle text-primary" id="dropdownMenuButton41" data-toggle="dropdown">\
                                                                     <i class="ri-more-2-line"></i>\
                                                                </span>\
                                                                <div class="dropdown-menu dropdown-menu-right" style="">\
                                                                    <a class="dropdown-item" href="#"><i class="ri-user-unfollow-line mr-2"></i>Unfollow</a>\
                                                                    <a class="dropdown-item" href="#"><i class="ri-close-circle-line mr-2"></i>Unfriend</a>\
                                                                    <a class="dropdown-item" href="#"><i class="ri-lock-line mr-2"></i>block</a>\
                                                                </div>\
                                                            </div>\
                                                        </div>\
                                                    </li>';

                $("#userlist").append(render);
            }
        }
    });
}


var select_category = new Vue({
    el: '#category',
    data: function() {
        return {
            selected: [],
            category: [],
            options: [],
            placeholder: 'Choose a Category..'
        };
    },
    methods: {
        selected_category: function(values) {
            c_select = this.selected.category;
            //console.log(u_select);
        },
    }
});

//push category to vue
function vue_category() {
    $.ajax({
        type: "post",
        url: '/getcategory',
        async: false,
        success: function(response) {
            var len = response.length;
            for (var i = 0; i < len; i++) {
                var json = { "category_id": response[i].category_id, "category": response[i].category };
                select_category.options.push(json);

                var category_id = response[i].category_id;
                var category = response[i].category;
                var category_style = response[i].category_style;

                var render = '<li class="paddingfix"><a href="javascript:void(0);" onclick ="category' + category_id + '();"><i class="ri-checkbox-blank-circle-fill ' + category_style + '"></i> ' + category + ' </a></li>';
                $("#category_list").append(render);
            }
        }
    });
}

function category0() {
    var xhttp = new XMLHttpRequest();

    xhttp.onreadystatechange = function() {
        if (this.readyState == 2 && this.status == 200) {
            category_task();
            console.log("addtask successful");
        }
        else if (this.readyState == 2 && this.status >= 400) {
            console.log("sort category failed");
        }
    };

    var category = "All Task";
    xhttp.open("POST", "/category0", true);
    xhttp.send(category);
}

function category1() {
    var xhttp = new XMLHttpRequest();

    xhttp.onreadystatechange = function() {
        if (this.readyState == 2 && this.status == 200) {
            category_task();
            console.log("addtask successful");
        }
        else if (this.readyState == 2 && this.status >= 400) {
            console.log("sort category failed");
        }
    };

    var category = "Webpage Design";
    xhttp.open("POST", "/category1", true);
    xhttp.send(category);
}

function category2() {
    var xhttp = new XMLHttpRequest();

    xhttp.onreadystatechange = function() {
        if (this.readyState == 2 && this.status == 200) {
            category_task();
            console.log("addtask successful");
        }
        else if (this.readyState == 2 && this.status >= 400) {
            console.log("sort category failed");
        }
    };

    var category = "Database";
    xhttp.open("POST", "/category2", true);
    xhttp.send(category);
}

function category3() {
    var xhttp = new XMLHttpRequest();

    xhttp.onreadystatechange = function() {
        if (this.readyState == 2 && this.status == 200) {
            category_task();
            console.log("addtask successful");
        }
        else if (this.readyState == 2 && this.status >= 400) {
            console.log("sort category failed");
        }
    };

    var category = "Internet Security";
    xhttp.open("POST", "/category3", true);
    xhttp.send(category);
}

function category4() {
    var xhttp = new XMLHttpRequest();

    xhttp.onreadystatechange = function() {
        if (this.readyState == 2 && this.status == 200) {
            category_task();
            console.log("addtask successful");
        }
        else if (this.readyState == 2 && this.status >= 400) {
            console.log("sort category failed");
        }
    };

    var category = "IOS App";
    xhttp.open("POST", "/category4", true);
    xhttp.send(category);
}

function gettask() {
    $.ajax({
        url: '/gettask',
        type: 'post',
        success: function(response) {
            var len = response.length;
            for (var i = 0; i < len; i++) {
                var task_id = response[i].task_id;
                var task_title = response[i].task_title;
                var task_date = response[i].task_date;
                var user_id = response[i].user_id;
                var category = response[i].category;
                var priority = response[i].priority;
                var task_assign = response[i].task_assign;
                var task_assignby = response[i].task_assignby;
                var icon = response[i].icon;

                var render = '<li class="d-flex align-items-center p-3">\
                                                <div class="user-img img-fluid"><img src="' + icon + '" alt="story-img" class="rounded-circle avatar-40"></div>\
                                                <div class="media-support-info ml-3">\
                                                    <h6 class="d-inline-block" id="tasktitle' + task_id + '">' + task_title + '</h6>\
                                                    <span id="' + priority + '" class="badge badge-' + priority + ' ml-3">' + priority + '</span>\
                                                    <p class="mb-0">by ' + task_assignby + ' </p>\
                                                </div>\
                                                <div class="iq-card-header-toolbar d-flex align-items-center">\
                                                    <div class="custom-control custom-checkbox">\
                                                        <input type="checkbox" name="todo-check" class="custom-control-input" id="check' + task_id + '">\
                                                        <label class="custom-control-label" for="check' + task_id + '"></label>\
                                                    </div>\
                                                </div>\
                                            </li>';

                $("#tasklist").append(render);
            }

        }
    });
}

function getuser() {
    $.ajax({
        url: '/getuser',
        type: 'post',
        dataType: 'JSON',
        success: function(response) {
            var len = response.length;
            for (var i = 0; i < len; i++) {
                var user_id = response[i].user_id;
                var full_name = response[i].full_name;
                var email = response[i].email;
                var icon = response[i].icon;

                var render = ' <li class="d-flex mb-4 align-items-center">\
                                                        <div class="user-img img-fluid"><img src="' + icon + '" alt="story-img" class="rounded-circle avatar-40"></div>\
                                                        <div class="media-support-info ml-3">\
                                                            <h6>' + full_name + '</h6>\
                                                            <p class="mb-0">' + email + '</p>\
                                                        </div>\
                                                        <div class="iq-card-header-toolbar d-flex align-items-center">\
                                                            <div class="dropdown">\
                                                                <span class="dropdown-toggle text-primary" id="dropdownMenuButton41" data-toggle="dropdown">\
                                                                     <i class="ri-more-2-line"></i>\
                                                                </span>\
                                                                <div class="dropdown-menu dropdown-menu-right" style="">\
                                                                    <a class="dropdown-item" href="#"><i class="ri-user-unfollow-line mr-2"></i>Unfollow</a>\
                                                                    <a class="dropdown-item" href="#"><i class="ri-close-circle-line mr-2"></i>Unfriend</a>\
                                                                    <a class="dropdown-item" href="#"><i class="ri-lock-line mr-2"></i>block</a>\
                                                                </div>\
                                                            </div>\
                                                        </div>\
                                                    </li>';
                $("#userlist").append(render);
            }

        }
    });
}

function getcategory() {
    $.ajax({
        url: '/getcategory',
        type: 'post',
        dataType: 'JSON',
        success: function(response) {
            var len = response.length;
            for (var i = 0; i < len; i++) {
                var category_id = response[i].category_id;
                var category = response[i].category;
                var category_style = response[i].category_style;

                var render = '<li class="paddingfix"><a href="' + category + " " + category_id + '();"><i class="ri-checkbox-blank-circle-fill ' + category_style + '"></i> ' + category + ' </a></li>';
                $("#category_list").append(render);
            }

        }
    });
}

$(document).ready(gettask);
//$(document).ready(getuser);
//$(document).ready(getcategory);
$(document).ready(vue_category);
$(document).ready(vue_user);

var status = 0;
var taskid;

function statuscheck() {
    if ($("#check" + taskid).is(":checked")) {
        status = $("#check" + taskid).val();
    }
    else {
        status = 0;
    }
    console.log(status);
}
