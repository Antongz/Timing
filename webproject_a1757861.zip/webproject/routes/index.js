var express = require('express');
const mysql = require("mysql");
var router = express.Router();
const app = express();
var sanitizeHtml = require('sanitize-html');
const bodyParser = require('body-parser');
var createError = require('http-errors');

/* GET home page. */
router.get('/', function(req, res, next) {
    res.sendFile('timing.html', { root: __dirname + '/../public' });
});

var login = 0;

/* Render pages. */

router.get('/todo', function(req, res, next) {
    if (login == 1) {
        res.sendFile('todo.html', { root: __dirname + '/../public' });
    }
    else {
        next(createError(404));
    }
});

router.get('/calendar', function(req, res, next) {
    if (login == 1) {
        res.sendFile('calendar.html', { root: __dirname + '/../public' });
    }
    else {
        next(createError(404));
    }

});

router.get('/add-user', function(req, res, next) {
    if (login == 1) {
        res.sendFile('add-user.html', { root: __dirname + '/../public' });
    }
    else {
        next(createError(404));
    }
});

router.get('/profile', function(req, res, next) {
    if (login == 1) {
        res.sendFile('profile.html', { root: __dirname + '/../public' });
    }
    else {
        next(createError(404));
    }

});

router.get('/profile-edit', function(req, res, next) {
    if (login == 1) {
        res.sendFile('profile-edit.html', { root: __dirname + '/../public' });
    }
    else {
        next(createError(404));
    }

});

router.get('/sign-in', function(req, res, next) {
    res.sendFile('sign-in.html', { root: __dirname + '/../public' });
});

router.get('/sign-up', function(req, res, next) {
    res.sendFile('sign-up.html', { root: __dirname + '/../public' });
});

router.get('/user-list', function(req, res, next) {
    if (login == 1) {
        res.sendFile('user-list.html', { root: __dirname + '/../public' });
    }
    else {
        next(createError(404));
    }
});

router.get('/timing', function(req, res, next) {
    res.sendFile('timing.html', { root: __dirname + '/../public' });
});

/* Login.*/
var user_email;
var firstname;
var familyname;
var full_name;
var admin;
var userid;
var icon = 'images/user/1.jpg';

router.post('/login', function(req, res, next) {

    //Get email and password from POST request
    var password = sanitizeHtml(req.body.password);
    var email = sanitizeHtml(req.body.email);
    user_email = email;

    //Connect to the database
    req.pool.getConnection(function(err, connection) {
        if (err) {
            throw err;
        }

        // Query to get user info
        var query = "SELECT user.user_id, admin, first_name, family_name, full_name, email, user_password, status_id, user_profile.icon FROM user INNER JOIN user_profile ON user.user_id = user_profile.user_id";
        connection.query(query, function(err, user) {
            var isTrue = false;
            if (err || user.length <= 0) {
                // No valid user found
                console.log(email + "  no user found");
                res.status(401).send();
                return;
            }

            // Check if password match
            if (user) {
                for (var i = 0; i < user.length; i++) {
                    //compare email and password
                    if (user[i].email == email && user[i].user_password == password) {
                        isTrue = true;
                        console.log("user found");

                        if (isTrue) {
                            // Correct password, store status
                            userid = user[i].user_id;
                            firstname = user[i].first_name;
                            familyname = user[i].family_name;
                            full_name = user[i].full_name;
                            admin = user[i].admin;
                            icon = user[i].icon;
                            //console.log(user[i].user_id);

                            var query = "UPDATE user SET status_id = 1 WHERE user_id = " + userid;
                            connection.query(query, function(err, user) {
                                if (err) throw err;
                            });
                            console.log("match " + user[i].status_id + " " + user[i].email + " is online.");
                            login = 1;
                            res.send();
                        }
                        else {
                            // Wrong password
                            console.log("wrong password or email address");
                            res.status(401).send();
                        }
                    }
                }
            }
            else {
                // login fail
                console.log("login fail");
                res.status(401).send();
            }
        });
    });
});

/* signout. */
router.post('/signout', function(req, res, next) {
    //Connect to the database
    req.pool.getConnection(function(err, connection) {
        if (err) {
            throw err;
        }

        var query = "SELECT * FROM user";
        connection.query(query, function(err, user) {
            var isTrue = false;
            if (err || user.length <= 0) {
                // No valid user found
                console.log(email + "  no user found");
                res.status(401).send();
                return;
            }
            if (user) {
                for (var i = 0; i < user.length; i++) {
                    if (user[i].email == user_email) {
                        isTrue = true;
                        console.log("user found");
                    }
                    if (isTrue) {
                        var userid = user[i].user_id;
                        var query = "UPDATE user SET status_id = 0 WHERE user_id = " + userid;
                        connection.query(query, function(err, user) {
                            if (err) {
                                res.status(403).send();
                            }
                            else {
                                //console.log("match " + user[i].email + " is away.");
                                login = 0;
                                res.send();
                            }
                        });
                    }
                }
            }
        });
    });
});

/* signup. */
router.post('/signup', function(req, res, next) {

    //Get email and password from POST request
    var password = sanitizeHtml(req.body.password);
    var email = sanitizeHtml(req.body.email);
    var firstname = sanitizeHtml(req.body.first_name);
    var familyname = sanitizeHtml(req.body.family_name);
    var admin = sanitizeHtml(req.body.admin);
    var fullname = firstname + ' ' + familyname;
    var user_id = 0;

    //Connect to the database
    req.pool.getConnection(function(err, connection) {
        if (err) { throw err; }

        var query = "SELECT * FROM user";
        connection.query(query, function(err, user) {
            if (err) {
                throw err;
            }
            else {

                for (var i = 0; i < user.length; i++) {
                    if (user_id < i) {
                        user_id = i;
                    }
                }

                //assign user id
                user_id = user_id + 2;
                console.log(user_id);

                var query = "INSERT INTO user VALUES ('" + user_id + "','" + admin + "','" + firstname + "','" + familyname + "','" + fullname + "','" + email + "','" + password + "',0)";
                connection.query(query, function(err, user) {
                    if (err) {
                        throw err;
                    }
                    else {
                        user_email = email;
                        login = 0;
                        res.status(200).send();
                    }
                });
            }
        });
    });
});


/* addtask. */
router.post('/addtask', function(req, res, next) {

    var task_title = sanitizeHtml(req.body.task_title);
    var task_assign = sanitizeHtml(req.body.u_select);
    var category = sanitizeHtml(req.body.c_select);
    var priority = sanitizeHtml(req.body.priority);
    var task_date = sanitizeHtml(req.body.date);
    var task_id = 0;

    //Connect to the database
    req.pool.getConnection(function(err, connection) {
        if (err) { throw err; }

        var query = "SELECT * FROM task";
        connection.query(query, function(err, task) {
            if (err) {
                throw err;
            }
            else {

                for (var i = 0; i < task.length; i++) {
                    if (task_id < i) {
                        task_id = i;
                    }
                }

                //assign user id
                task_id = task_id + 2;
                console.log(task_id);

                var query = "INSERT INTO task VALUES ('" + task_id + "','" + task_title + "','" + task_date + "','" + userid + "','" + category + "','" + priority + "','" + task_assign + "','" + full_name + "')";
                connection.query(query, function(err, task) {
                    if (err) {
                        throw err;
                    }
                    else {
                        res.status(200).send();
                    }
                });
            }
        });
    });
    //console.log(task_title + " " + priority + " " + user_select + " " + category_select + " " + date);
});

/* render_footer. */
router.get('/footer', function(req, res, next) {
    res.send(' <div class="container-fluid">\
            <div class="row">\
                <div class="col-lg-6">\
                    <ul class="list-inline mb-0">\
                        <li class="list-inline-item"><a href="/404">Privacy Policy</a></li>\
                        <li class="list-inline-item"><a href="/404">Terms of Use</a></li>\
                    </ul>\
                </div>\
                <div class="col-lg-6 text-right">\
                    Copyright 2020 <a href="/timing">Timing</a> All Rights Reserved.\
                </div>\
            </div>\
        </div>');
});

/* render_sidebar. */
router.get('/sidebar', function(req, res, next) {
    if (admin == 1) {
        res.send('<div class="iq-sidebar-logo d-flex justify-content-between">\
                <a href="todo">\
                 <img src="images/logo.gif" class="img-fluid" alt="">\
                 <span>Timing</span>\
                </a>\
                <div class="iq-menu-bt align-self-center">\
                    <div class="wrapper-menu">\
                        <div class="line-menu half start"></div>\
                        <div class="line-menu"></div>\
                        <div class="line-menu half end"></div>\
                    </div>\
                </div>\
            </div>\
            <div id="sidebar-scrollbar">\
                <nav class="iq-sidebar-menu">\
                    <ul id="iq-sidebar-toggle" class="iq-menu">\
                        <li class="iq-menu-title"><i class="ri-separator"></i><span>Main</span></li>\
                        <li><a href="todo" class="iq-waves-effect"><i class="las la-check-square"></i><span>Todo</span></a></li>\
                        <li>\
                            <a href="#user-info" class="iq-waves-effect collapsed" data-toggle="collapse" aria-expanded="false"><i class="las la-user-tie"></i><span>User</span><i class="ri-arrow-right-s-line iq-arrow-right"></i></a>\
                            <ul id="user-info" class="iq-submenu collapse" data-parent="#iq-sidebar-toggle">\
                                <li><a href="profile">User Profile</a></li>\
                                <li><a href="profile-edit">User Edit</a></li>\
                                <li><a href="add-user">User Add</a></li>\
                                <li><a href="user-list">User List</a></li>\
                            </ul>\
                        </li>\
                        <li><a href="calendar" class="iq-waves-effect"><i class="las la-calendar"></i><span>Calendar</span></a></li>\
                    </ul>\
                </nav>\
                <div class="p-3"></div>\
            </div>');
    }
    else {
        res.send('<div class="iq-sidebar-logo d-flex justify-content-between">\
                <a href="todo">\
                 <img src="images/logo.gif" class="img-fluid" alt="">\
                 <span>Timing</span>\
                </a>\
                <div class="iq-menu-bt align-self-center">\
                    <div class="wrapper-menu">\
                        <div class="line-menu half start"></div>\
                        <div class="line-menu"></div>\
                        <div class="line-menu half end"></div>\
                    </div>\
                </div>\
            </div>\
            <div id="sidebar-scrollbar">\
                <nav class="iq-sidebar-menu">\
                    <ul id="iq-sidebar-toggle" class="iq-menu">\
                        <li class="iq-menu-title"><i class="ri-separator"></i><span>Main</span></li>\
                        <li><a href="todo" class="iq-waves-effect"><i class="las la-check-square"></i><span>Todo</span></a></li>\
                        <li><a href="calendar" class="iq-waves-effect"><i class="las la-calendar"></i><span>Calendar</span></a></li>\
                    </ul>\
                </nav>\
                <div class="p-3"></div>\
            </div>');
    }
});

/* render_nav_bar. */
router.get('/render_nav_bar', function(req, res, next) {
    res.send('<div class="iq-navbar-custom">\
    <div class="iq-sidebar-logo">\
        <div class="top-logo">\
            <a href="todo" class="logo">\
               <img src="images/logo.gif" class="img-fluid" alt="">\
                <span>Timing</span>\
            </a>\
        </div>\
    </div>\
    <div class="navbar-breadcrumb">\
        <h5 class="mb-0">Todo</h5>\
        <nav aria-label="breadcrumb">\
            <ol class="breadcrumb">\
                <li class="breadcrumb-item"><a href="todo">Home</a></li>\
                <li class="breadcrumb-item active" aria-current="page">Todo</li>\
            </ol>\
        </nav>\
    </div>\
    <nav class="navbar navbar-expand-lg navbar-light p-0">\
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">\
                  <i class="ri-alarm-warning-line"></i>\
                  </button>\
        <div class="iq-menu-bt align-self-center">\
            <div class="wrapper-menu">\
                <div class="line-menu half start"></div>\
                <div class="line-menu"></div>\
                <div class="line-menu half end"></div>\
            </div>\
        </div>\
        <div class="collapse navbar-collapse" id="navbarSupportedContent">\
            <ul class="navbar-nav ml-auto navbar-list">\
                <li class="nav-item dropdown">\
                    <a href="#" class="search-toggle iq-waves-effect">\
                              <i class="ri-mail-line"></i>\
                              <span class="badge badge-pill badge-dark badge-up count-mail">1</span>\
                           </a>\
                    <div class="iq-sub-dropdown">\
                        <div class="iq-card shadow-none m-0">\
                            <div class="iq-card-body p-0 ">\
                                <div class="bg-primary p-3">\
                                    <h5 class="mb-0 text-white">All Messages<small class="badge  badge-light float-right pt-1">1</small></h5>\
                                </div>\
                                <a href="#" class="iq-sub-card">\
                                    <div class="media align-items-center">\
                                        <div class="">\
                                            <img class="avatar-40 rounded" src="images/user/02.jpg" alt="">\
                                        </div>\
                                        <div class="media-body ml-3">\
                                            <h6 class="mb-0 ">Nai Luc</h6>\
                                            <small class="float-left font-size-12">13 Jun</small>\
                                        </div>\
                                    </div>\
                                </a>\
                            </div>\
                        </div>\
                    </div>\
                </li>\
                <li class="nav-item">\
                    <a href="#" class="search-toggle iq-waves-effect">\
                              <i class="ri-notification-2-line"></i>\
                              <span class="bg-danger dots"></span>\
                           </a>\
                    <div class="iq-sub-dropdown">\
                        <div class="iq-card shadow-none m-0">\
                            <div class="iq-card-body p-0 ">\
                                <div class="bg-danger p-3">\
                                    <h5 class="mb-0 text-white">All Notifications<small class="badge  badge-light float-right pt-1">1</small></h5>\
                                </div>\
                                <a href="#" class="iq-sub-card">\
                                    <div class="media align-items-center">\
                                        <div class="media-body ml-3">\
                                            <h6 class="mb-0 ">New Task Recieved</h6>\
                                            <small class="float-right font-size-12">23 hrs ago</small>\
                                            <p class="mb-0">Fix critical crashes</p>\
                                        </div>\
                                    </div>\
                                </a>\
                            </div>\
                        </div>\
                    </div>\
                </li>\
                <li class="nav-item iq-full-screen"><a href="#" class="iq-waves-effect" id="btnFullscreen"><i class="ri-fullscreen-line"></i></a></li>\
            </ul>\
        </div>\
        <ul class="navbar-list">\
            <li>\
                <a href="#" class="search-toggle iq-waves-effect bg-primary text-white"><img src="' + icon + '" class="img-fluid rounded" alt="user"></a> \
                <div class = "iq-sub-dropdown iq-user-dropdown" >\
                <div class="iq-card shadow-none m-0">\
                        <div class="iq-card-body p-0 ">\
                            <div class="bg-primary p-3">\
                                <h5 class="mb-0 text-white line-height">Hello ' + firstname + ' ' + familyname + '</h5>\
                                <span class="text-white font-size-12">Available</span>\
                            </div>\
                            <a href="profile" class="iq-sub-card iq-bg-primary-hover">\
                                <div class="media align-items-center">\
                                    <div class="rounded iq-card-icon iq-bg-primary">\
                                        <i class="ri-file-user-line"></i>\
                                    </div>\
                                    <div class="media-body ml-3 ml-fix">\
                                        <h6 class="mb-0 ">My Profile</h6>\
                                        <p class="mb-0 font-size-12">View personal profile details.</p>\
                                    </div>\
                                </div>\
                            </a>\
                            <a href="profile-edit" class="iq-sub-card iq-bg-primary-success-hover">\
                                <div class="media align-items-center">\
                                    <div class="rounded iq-card-icon iq-bg-success">\
                                        <i class="ri-profile-line"></i>\
                                    </div>\
                                    <div class="media-body ml-3 ml-fix">\
                                        <h6 class="mb-0 ">Edit Profile</h6>\
                                        <p class="mb-0 font-size-12">Modify your personal details.</p>\
                                    </div>\
                                </div>\
                            </a>\
                            <div class="d-inline-block w-100 text-center p-3">\
                                <button class="iq-bg-danger iq-sign-btn" role="button" onclick="signout();">Sign out<i class="ri-login-box-line ml-2"></i></button>\
                            </div>\
                        </div>\
                    </div>\
                    </div>\
                    <li>\
                </ul>\
                </nav>\
                </div>');
});

/* render_tasklist. */
router.get('/tasklist', function(req, res, next) {
    res.send('<li class="d-flex align-items-center p-3">\
                <div class="user-img img-fluid"><img src="images/user/01.jpg" alt="story-img" class="rounded-circle avatar-40"></div>\
                    <div class="media-support-info ml-3">\
                        <h6 class="d-inline-block">Landing page for secret Project</h6><span class="badge badge-warning ml-3 text-white">Long-term</span>\
                        <p class="mb-0">by Danlel Cllfferton</p>\
                    </div>\
                    <div class="iq-card-header-toolbar d-flex align-items-center">\
                        <div class="custom-control custom-checkbox">\
                        <input type="checkbox" name="todo-check" class="custom-control-input" id="check1">\
                        <label class="custom-control-label" for="check1"></label>\
                    </div>\
                </div>\
             </li>');
});


/* gettask. */
var setcategory = " ";
var setuser = "(task_assign LIKE '%" + full_name + "%' OR task_assignby LIKE '%" + full_name + "%'";

function alltask() {
    setcategory = " ";
}

function webpage_design() {
    setcategory = " category = 'Webpage Design' AND ";
}

function database() {
    setcategory = " category = 'Database' AND ";
}

function internet_security() {
    setcategory = " category = 'Internet Security' AND ";
}

function ios_app() {
    setcategory = " category = 'IOS App' AND ";
}

router.post('/gettask', function(req, res, next) {

    //Connect to the database
    req.pool.getConnection(function(err, connection) {
        if (err) { throw err; }
        if (connection) {
            var query = "SELECT task_id, task_title, task_date, task.user_id, category, priority, task_assign, task_assignby, user_profile.icon FROM task INNER JOIN user_profile ON task.user_id = user_profile.user_id WHERE" + setcategory + "(task_assign LIKE '%" + full_name + "%' OR task_assignby LIKE '%" + full_name + "%') ORDER BY task_id DESC";
            connection.query(query, function(err, task) {
                if (err) {
                    throw err;
                }
                if (task) {
                    res.json(task);
                }
                else {
                    res.status(200).send();
                }
            });
        }
        else {
            console.log('lose connetion');
            res.status(200).send();
        }

    });

});

function to2(m) {
    if (m < 10) {
        return '0' + m;
    }
    return m;
}

router.post('/getschedule', function(req, res, next) {

    var myDate = new Date();
    var year = myDate.getFullYear();
    var month = to2(myDate.getMonth() + 1);
    var day = to2(myDate.getDate());
    var today = year + "-" + month + "-" + day;

    //Connect to the database
    req.pool.getConnection(function(err, connection) {
        if (err) { throw err; }
        if (connection) {
            var query = "SELECT task_title, task_date, category.category_style FROM task INNER JOIN category ON task.category = category.category INNER JOIN user_profile ON task.user_id = user_profile.user_id WHERE task_assign LIKE '%" + full_name + "%' AND (task_date LIKE '%" + today + "%') ORDER BY task_id DESC";
            connection.query(query, function(err, task) {
                if (err) {
                    throw err;
                }
                if (task) {
                    res.json(task);
                }
                else {
                    res.status(200).send();
                }
            });
        }
        else {
            console.log('lose connetion');
            res.status(200).send();
        }
    });

});

router.post('/getevent', function(req, res, next) {

    //Connect to the database
    req.pool.getConnection(function(err, connection) {
        if (err) { throw err; }
        if (connection) {
            var query = "SELECT task_title, task_date, category.category_style FROM task INNER JOIN category ON task.category = category.category INNER JOIN user_profile ON task.user_id = user_profile.user_id WHERE (task_assign LIKE '%" + full_name + "%' OR task_assignby LIKE '%" + full_name + "%') ORDER BY task_id DESC";
            connection.query(query, function(err, task) {
                if (err) {
                    throw err;
                }
                if (task) {
                    res.json(task);
                }
                else {
                    res.status(200).send();
                }
            });
        }
        else {
            console.log('lose connetion');
            res.status(200).send();
        }
    });

});

/* getuser. */
router.post('/getuser', function(req, res, next) {

    //Connect to the database
    req.pool.getConnection(function(err, connection) {
        if (err) { throw err; }
        if (connection) {
            var query = "SELECT user.user_id, admin, first_name, family_name, full_name, email, user_password, status_id, user_profile.icon FROM user INNER JOIN user_profile ON user.user_id = user_profile.user_id";
            connection.query(query, function(err, user) {
                if (err) {
                    throw err;
                }
                if (user) {
                    res.json(user);
                }
                else {
                    res.status(200).send();
                }
            });
        }
        else {
            console.log('lose connetion');
            res.status(200).send();
        }
    });
});

/* getcategory. */
router.post('/getcategory', function(req, res, next) {

    //Connect to the database
    req.pool.getConnection(function(err, connection) {
        if (err) { throw err; }
        if (connection) {
            var query = "SELECT* FROM category";
            connection.query(query, function(err, category) {
                if (err) {
                    throw err;
                }
                if (category) {
                    res.json(category);
                }
                else {
                    res.status(200).send();
                }
            });
        }
        else {
            console.log('lose connetion');
            res.status(200).send();
        }
    });
});


/* sortcategory. */
router.post('/category0', function(req, res, next) {
    alltask();
    //console.log(setcategory);
    res.status(200).send();
});

router.post('/category1', function(req, res, next) {
    webpage_design();
    //console.log(setcategory);
    res.status(200).send();
});

router.post('/category2', function(req, res, next) {
    database();
    //console.log(setcategory);
    res.status(200).send();
});

router.post('/category3', function(req, res, next) {
    internet_security();
    //console.log(setcategory);
    res.status(200).send();
});

router.post('/category4', function(req, res, next) {
    ios_app();
    //console.log(setcategory);
    res.status(200).send();
});

/* addcategory. */
router.post('/addcategory', function(req, res, next) {

    //Connect to the database
    req.pool.getConnection(function(err, connection) {
        if (err) { throw err; }
    });
    res.status(200).send();
});

/* book appointment. */
router.post('/book_appointment', function(req, res, next) {

    //Connect to the database
    req.pool.getConnection(function(err, connection) {
        if (err) { throw err; }
    });
    res.status(200).send();
});

/* add_classification. */
router.post('/add_classification', function(req, res, next) {

    //Connect to the database
    req.pool.getConnection(function(err, connection) {
        if (err) { throw err; }
    });
    res.status(200).send();
});

module.exports = router;
